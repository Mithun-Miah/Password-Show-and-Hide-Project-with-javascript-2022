let pass = document.getElementById("password");

        function myPass(){
            if(pass.type == "password"){
                pass.type = "text";
            }else{
                pass.type = "password";
            }
        }